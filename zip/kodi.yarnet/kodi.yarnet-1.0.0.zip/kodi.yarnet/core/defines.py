# -*- coding: utf-8 -*-

SITE_DOMAIN = 'yar-net.ru'
SITE_URL = 'http://'+SITE_DOMAIN+'/video/autovokzal_1'
PLUGIN_ID = 'kodi.yarnet'
CACHE_DATABASE = 'yarnet.cache.db'
COOKIE_FILE = 'yarnet_cookie.txt'
