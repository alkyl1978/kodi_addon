# -*- coding: utf-8 -*-

SITE_DOMAIN = 'zonavideo.org'
SITE_URL = 'http://'+SITE_DOMAIN
PLUGIN_ID = 'plugin.video.zona.video.dev'
CACHE_DATABASE = 'zonamobi.cache.db'
COOKIE_FILE = 'zonamobi_cookie.txt'

QUALITYS = [None, '360', '480', '720', '1080']
